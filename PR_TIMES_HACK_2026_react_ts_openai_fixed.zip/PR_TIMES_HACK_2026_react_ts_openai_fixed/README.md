# PR Continuity Assistant — React + TypeScript + OpenAI + pgvector

中小企業が「1度プレスリリースを出したが、次に何を出せばよいか分からず止まる」課題を解くハッカソンMVPです。

## この版で実装したこと

- Frontend: React + TypeScript + Vite
- Backend: Node.js + Express + TypeScript
- DB: PostgreSQL + pgvector
- AI文章生成: OpenAI Responses API
- ベクトル化: OpenAI Embeddings API (`text-embedding-3-small`, 384 dimensions)
- Docker ComposeでDB / Backend / Frontendを一括起動
- EC2向けComposeを同梱
- 元リポジトリの `company`, `release`, `release_type`, `release_statistic` を維持
- ダミー10社・36本のプレスリリースデータ
- AI生成結果とEmbeddingをDBキャッシュ

## ユーザー体験

メイン画面に出す推薦は **各1件だけ** です。

### 1. 次の1本

対象企業の会社概要 + 過去配信をEmbeddingし、他社の投稿済みプレスリリースとpgvectorで比較します。

そのうえで、以下のスコアで候補を再ランキングします。

- 55%: ベクトル類似度
- 20%: 自社でまだ配信していないジャンル
- 10%: 同業界
- 15%: 他社事例のPV実績

最上位の未配信ジャンル事例をOpenAIへ渡し、対象企業向けの「次の1本」の文章を生成します。

### 2. 過去配信 × 新ジャンル

新ジャンルの他社事例ごとに、対象企業の過去プレスリリースの中からEmbedding距離が最も近い1本を探します。

例:

```text
過去配信
「予約管理サービス Minato Reserve を提供開始」
        ×
新ジャンル
「導入事例・実績」
        ↓
OpenAI
「サービス開始の続報として、導入後の利用実績・現場の変化を発信する」
```

ゼロからネタを探すのではなく、過去に出した内容の「その後」を新ジャンルへ変換する設計です。

### 3. 他の候補一覧

トップには大量の候補を表示しません。

`他の候補・事例一覧を見る` を押した人だけが右側のドロワーで、上位20件の類似他社事例を確認できます。

### 4. 12か月PR計画

別タブでOpenAIが以下を組み合わせ、各月1件だけ年間計画を作ります。

- 過去配信の続編
- 未配信ジャンル
- 類似他社事例
- 季節・年間計画

実在しない実績を生成しないよう、分からない情報は「社内で確認する情報」として表示します。

---

# ローカル起動

> **重要:** チャット・Issue・GitHub・スクリーンショット等に貼ったAPIキーは使い回さず、新しいキーを発行して `.env` に設定してください。`.env` は `.gitignore` 対象です。

## 0. 以前のTS5096エラーについて

この版では `frontend/tsconfig.node.json` から問題の `allowImportingTsExtensions` 設定を除去済みです。

```text
TS5096: Option 'allowImportingTsExtensions' can only be used ...
```

が出ていた旧版は、この修正版へ置き換えてください。

## 1. `.env` を作る

手動で作る場合:

```bash
cp .env.example .env
```

または、キーを画面に表示せず作る場合:

```bash
./scripts/setup-env.sh
```

`.env` を開いてOpenAI APIキーを設定します。

```env
OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxx
OPENAI_TEXT_MODEL=gpt-5.6-terra
OPENAI_EMBEDDING_MODEL=text-embedding-3-small

POSTGRES_DB=prtimes
POSTGRES_USER=prtimes
POSTGRES_PASSWORD=prtimes-local
POSTGRES_PORT=5432
APP_PORT=80
```

**APIキーをReact側やGitHubへ入れないでください。** キーはBackendコンテナだけに渡されます。

## 2. Docker Desktopを起動

Macの場合はDocker Desktopを起動してから、プロジェクト直下で実行します。

```bash
docker compose up --build
```

または

```bash
make up
```

## 3. ブラウザで開く

```text
http://localhost
```

`APP_PORT=8080` にした場合は `http://localhost:8080` です。

初回の推薦表示時だけ、OpenAI Embeddings APIで36本のリリース + 10社の企業PRプロフィールをベクトル化します。DBへ保存するため、2回目以降は同じEmbeddingを再生成しません。

## 4. 動作確認

```bash
./scripts/smoke.sh
```

成功すると:

```text
SMOKE TEST OK
```

---

# 主なAPI

```text
GET  /api/health
GET  /api/companies
GET  /api/companies/:companyId/dashboard
GET  /api/companies/:companyId/recommendations
GET  /api/companies/:companyId/recommendations?refresh=true
GET  /api/companies/:companyId/recommendation-candidates
GET  /api/companies/:companyId/annual-plan
GET  /api/companies/:companyId/annual-plan?refresh=true
POST /api/admin/embeddings/refresh
POST /api/companies/:companyId/cache/clear
```

`refresh=true` のときだけOpenAIで提案文を再生成します。通常表示では `ai_generation_cache` を使うため、画面リロードのたびに生成APIを呼びません。

---

# DBに追加したテーブル

## `release_embedding`

他社リリース検索用Embedding。

```text
(company_id, release_id)
embedding vector(384)
embedding_text
embedding_model
updated_at
```

HNSW + cosine distance index付きです。

## `company_pr_embedding`

会社概要 + その会社の過去配信全体を1つの「PRプロフィール」としてEmbeddingしたものです。

## `ai_generation_cache`

OpenAIが作った以下のJSONをキャッシュします。

- 通常提案
- 過去配信 × 新ジャンル提案
- 12か月PR計画

---

# Recommendationの流れ

```text
company
 +
過去 release
        ↓
OpenAI Embeddings API
        ↓
company_pr_embedding (384d)
        ↓
pgvector cosine search
        ↓
類似する他社 release
        ↓
未配信ジャンル / 同業界 / PV を加味してrerank
        ↓
┌──────────────────────┐
│ A. 次の1本           │
│ 新ジャンル事例 1件   │
└──────────────────────┘
        ↓ OpenAI Responses API
        ↓
対象企業向け提案文

┌──────────────────────────────┐
│ B. 過去配信 × 新ジャンル     │
│ 他社新ジャンル事例           │
│       ×                      │
│ 最も近い自社の過去release    │
└──────────────────────────────┘
        ↓ OpenAI Responses API
        ↓
「過去のその後」を使った提案文
```

OpenAIへのプロンプトでは、入力に存在しない売上・導入数・提携等を捏造しないよう明示しています。

---

# DBを最初から作り直す

SQLやダミーデータを変更した場合、PostgreSQLのDocker volumeを消してください。

```bash
docker compose down -v
docker compose up --build
```

または

```bash
make reset
```

---

# EC2デプロイ

EC2では `docker-compose.ec2.yml` を使います。この構成ではPostgreSQLとBackendをホストへ公開せず、Frontend/NginxのHTTPポートだけ公開します。

## EC2に置いた後

```bash
cp .env.example .env
nano .env
```

本番では最低限、以下を変更してください。

```env
OPENAI_API_KEY=実際のAPIキー
POSTGRES_PASSWORD=十分に長いランダムなパスワード
APP_PORT=80
```

起動:

```bash
docker compose -f docker-compose.ec2.yml up -d --build
```

ログ:

```bash
docker compose -f docker-compose.ec2.yml logs -f --tail=200
```

停止:

```bash
docker compose -f docker-compose.ec2.yml down
```

EC2 Security Groupは、最低限HTTP 80を利用者から許可します。本番公開する場合はALBまたはリバースプロキシでHTTPS化し、443を使う構成を推奨します。PostgreSQL 5432やBackend 3000をインターネットへ公開する必要はありません。

## EC2で更新するとき

GitHubからpullする運用なら:

```bash
git pull
docker compose -f docker-compose.ec2.yml up -d --build
```

DBのvolumeは維持されるので、通常の再buildではデータは消えません。

---

# デモで見る企業

`株式会社ミナトテック` (company_id=1) は、2025年11月20日を最後に配信が止まっているダミー企業です。

過去配信:

1. 新商品・新サービス
2. アップデート・機能追加

そのため、導入事例、調査、イベント、地域連携、提携などが「未配信ジャンル」として推薦候補になります。

---

# 本番データへ差し替えるとき

現在の `db/03-seed.sql` はデモ用です。本番ではPR TIMES側の既存 `release` テーブルに実データが入っている前提で、ダミーseedを外してください。

新しいリリースをDBへ追加した後は:

```bash
curl -X POST http://localhost/api/admin/embeddings/refresh
```

を呼ぶとEmbeddingを更新し、AI提案キャッシュをクリアします。

将来的にはこの処理を「新規release登録時のジョブ」にすれば、本番運用で手動更新は不要です。
