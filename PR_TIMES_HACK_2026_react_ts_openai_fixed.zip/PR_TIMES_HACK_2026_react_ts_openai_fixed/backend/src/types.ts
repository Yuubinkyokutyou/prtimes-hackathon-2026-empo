export interface Company {
  company_id: number;
  company_name: string;
  description: string;
  industry_id: number;
  industry_name: string;
}

export interface ReleaseHistory {
  company_id: number;
  release_id: number;
  title: string;
  subtitle: string;
  lead_paragraph: string;
  body: string;
  release_type_id: number | null;
  release_type_name: string;
  created_at: string;
  page_view: number;
  unique_user: number;
  like_count: number;
}

export interface Candidate {
  company_id: number;
  release_id: number;
  company_name: string;
  company_industry_id: number;
  industry_name: string;
  title: string;
  lead_paragraph: string;
  release_type_id: number | null;
  release_type_name: string;
  created_at: string;
  page_view: number;
  similarity: number;
  sameIndustry: boolean;
  isNewGenre: boolean;
  popularity: number;
  score: number;
  closestPastRelease?: {
    release_id: number;
    title: string;
    release_type_name: string;
    similarity: number;
  };
}

export interface GeneratedRecommendation {
  headline: string;
  genre: string;
  proposal: string;
  why: string;
  next_actions: string[];
}

export interface CrossoverRecommendation extends GeneratedRecommendation {
  past_release_hook: string;
}
