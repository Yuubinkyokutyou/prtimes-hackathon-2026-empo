export const config = {
  port: Number(process.env.PORT ?? 3000),
  databaseUrl:
    process.env.DATABASE_URL ??
    'postgresql://prtimes:prtimes@localhost:5432/prtimes',
  openaiApiKey: process.env.OPENAI_API_KEY ?? '',
  openaiTextModel: process.env.OPENAI_TEXT_MODEL ?? 'gpt-5.6-terra',
  openaiEmbeddingModel:
    process.env.OPENAI_EMBEDDING_MODEL ?? 'text-embedding-3-small',
  embeddingDimensions: 384,
  cacheVersion: 'v3-openai-crossover',
};
