import { config } from './config';
import { one, query } from './db';
import { cleanJsonText, getOpenAI } from './openaiClient';
import { getCandidateList, getCompanyContext } from './recommendations';

interface PlanMonth {
  month: string;
  genre: string;
  headline: string;
  concept: string;
  source: string;
  internalInfo: string[];
}

export interface AnnualPlan {
  generatedAt: string;
  model: string;
  aiStatus: 'ok' | 'fallback';
  months: PlanMonth[];
}

function nextMonths(count = 12): string[] {
  const now = new Date();
  return Array.from({ length: count }, (_, index) => {
    const d = new Date(now.getFullYear(), now.getMonth() + index, 1);
    return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}`;
  });
}

async function cache(companyId: number, key: string): Promise<AnnualPlan | null> {
  const row = await one<{ payload: AnnualPlan }>(`
    SELECT payload FROM ai_generation_cache WHERE company_id = $1 AND cache_key = $2
  `, [companyId, key]);
  return row?.payload ?? null;
}

async function save(companyId: number, key: string, payload: AnnualPlan): Promise<void> {
  await query(`
    INSERT INTO ai_generation_cache(company_id, cache_key, payload, model, generated_at)
    VALUES ($1, $2, $3::jsonb, $4, now())
    ON CONFLICT (company_id, cache_key) DO UPDATE SET
      payload = EXCLUDED.payload,
      model = EXCLUDED.model,
      generated_at = now()
  `, [companyId, key, JSON.stringify(payload), config.openaiTextModel]);
}

export async function getAnnualPlan(
  companyId: number,
  refresh = false,
): Promise<AnnualPlan> {
  const cacheKey = `${config.cacheVersion}:annual-plan`;
  if (!refresh) {
    const cached = await cache(companyId, cacheKey);
    if (cached) return cached;
  }

  const context = await getCompanyContext(companyId);
  const candidates = await getCandidateList(companyId);
  const months = nextMonths();
  const history = context.history.slice(0, 8).map((r) => ({
    genre: r.release_type_name,
    title: r.title,
    date: r.created_at,
  }));
  const examples = candidates.slice(0, 12).map((c) => ({
    genre: c.release_type_name,
    company: c.company_name,
    title: c.title,
    similarity: Number(c.similarity.toFixed(3)),
  }));

  const prompt = `
以下の企業がプレスリリースを止めずに継続できるよう、12か月のPR計画を作ってください。

対象企業:
${JSON.stringify(context.company, null, 2)}

過去配信:
${JSON.stringify(history, null, 2)}

ベクトル検索で見つかった類似他社事例:
${JSON.stringify(examples, null, 2)}

対象月:
${JSON.stringify(months)}

要件:
- 過去と同じジャンルだけを繰り返さず、新ジャンルと「過去配信のその後」をバランス良く混ぜる。
- 新商品がなくても出せる、導入実績、調査、イベント、地域連携、提携、採用、周年、アップデート等を活用する。
- 実在しない実績・数字・提携を捏造しない。必要な事実は internalInfo に「社内で確認する情報」として書く。
- source は「過去配信の続編」「類似他社事例」「季節・年間計画」のいずれか。
- 各月に1件のみ。
- 出力は次のJSONのみ。
{
  "months": [
    {
      "month": "YYYY-MM",
      "genre": "ジャンル",
      "headline": "企画タイトル",
      "concept": "具体案を80〜140文字",
      "source": "過去配信の続編|類似他社事例|季節・年間計画",
      "internalInfo": ["確認情報1", "確認情報2"]
    }
  ]
}
`.trim();

  let plan: AnnualPlan;
  try {
    const client = getOpenAI();
    const response = await client.responses.create({
      model: config.openaiTextModel,
      instructions:
        '中小企業向けの現実的な年間PR計画を日本語で作り、指定JSON以外は出力しないでください。',
      input: prompt,
    });
    const parsed = JSON.parse(cleanJsonText(response.output_text));
    if (!Array.isArray(parsed.months) || parsed.months.length !== 12) {
      throw new Error('annual plan JSON must contain exactly 12 months');
    }
    plan = {
      generatedAt: new Date().toISOString(),
      model: config.openaiTextModel,
      aiStatus: 'ok',
      months: parsed.months,
    };
  } catch (error) {
    console.error('OpenAI annual plan generation failed:', error);
    plan = {
      generatedAt: new Date().toISOString(),
      model: config.openaiTextModel,
      aiStatus: 'fallback',
      months: months.map((month, index) => {
        const candidate = candidates[index % Math.max(candidates.length, 1)];
        return {
          month,
          genre: candidate?.release_type_name ?? '継続発信',
          headline: candidate
            ? `${candidate.release_type_name}の切り口を検討する`
            : '今月の社内トピックを発掘する',
          concept: candidate
            ? `${candidate.company_name}の「${candidate.title}」を参考に、自社に存在する事実だけで発信可能な切り口を探します。`
            : '各部署から変化・実績・イベント予定を集め、発信可能な事実を1つ選びます。',
          source: '類似他社事例',
          internalInfo: ['今月の変化・実績', '担当者コメント'],
        };
      }),
    };
  }

  await save(companyId, cacheKey, plan);
  return plan;
}
