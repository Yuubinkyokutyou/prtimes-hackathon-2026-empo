import { config } from './config';
import { getOpenAI } from './openaiClient';
import { pool, query, withTransaction } from './db';
import { Company, ReleaseHistory } from './types';

function vectorLiteral(values: number[]): string {
  return `[${values.map((v) => Number(v).toFixed(8)).join(',')}]`;
}

function releaseText(row: Record<string, unknown>): string {
  return [
    row.company_name,
    row.industry_name,
    row.company_description,
    row.release_type_name,
    row.title,
    row.title,
    row.lead_paragraph,
    row.lead_paragraph,
    row.body,
  ]
    .filter(Boolean)
    .join(' ');
}

export function companyProfileText(
  company: Company,
  history: ReleaseHistory[],
): string {
  const releaseLines = history.map(
    (r) =>
      `${r.release_type_name}｜${r.title}｜${r.lead_paragraph}｜${r.body}`,
  );
  return [
    `会社名: ${company.company_name}`,
    `業界: ${company.industry_name}`,
    `会社概要: ${company.description}`,
    `過去のプレスリリース: ${releaseLines.join(' / ')}`,
  ].join('\n');
}

export async function createEmbeddings(inputs: string[]): Promise<number[][]> {
  if (inputs.length === 0) return [];
  const client = getOpenAI();
  const response = await client.embeddings.create({
    model: config.openaiEmbeddingModel,
    input: inputs,
    dimensions: config.embeddingDimensions,
    encoding_format: 'float',
  });
  return response.data
    .sort((a, b) => a.index - b.index)
    .map((item) => Array.from(item.embedding));
}

export async function refreshAllEmbeddings(): Promise<{
  releases: number;
  companies: number;
}> {
  const releaseRows = await query<Record<string, unknown>>(`
    SELECT r.company_id, r.release_id, r.title, r.lead_paragraph, r.body,
           c.company_name, c.description AS company_description,
           c.industry_id, i.industry_name,
           COALESCE(rt.release_type_name, '') AS release_type_name
    FROM release r
    JOIN company c ON c.company_id = r.company_id
    JOIN industry i ON i.industry_id = c.industry_id
    LEFT JOIN release_type rt ON rt.release_type_id = r.release_type_id
    ORDER BY r.company_id, r.release_id
  `);

  const releaseTexts = releaseRows.map(releaseText);
  const releaseVectors = await createEmbeddings(releaseTexts);

  const companies = await query<Company>(`
    SELECT c.company_id, c.company_name, c.description, c.industry_id, i.industry_name
    FROM company c JOIN industry i ON i.industry_id = c.industry_id
    ORDER BY c.company_id
  `);

  const histories = await query<ReleaseHistory>(`
    SELECT r.company_id, r.release_id, r.title, r.subtitle, r.lead_paragraph, r.body,
           r.release_type_id, COALESCE(rt.release_type_name, '') AS release_type_name,
           r.created_at::text,
           COALESCE(rs.page_view, 0) AS page_view,
           COALESCE(rs.unique_user, 0) AS unique_user,
           COALESCE(rs.like_count, 0) AS like_count
    FROM release r
    LEFT JOIN release_type rt ON rt.release_type_id = r.release_type_id
    LEFT JOIN release_statistic rs ON rs.company_id = r.company_id AND rs.release_id = r.release_id
    ORDER BY r.company_id, r.created_at DESC
  `);

  const historyMap = new Map<number, ReleaseHistory[]>();
  for (const item of histories) {
    const list = historyMap.get(item.company_id) ?? [];
    list.push(item);
    historyMap.set(item.company_id, list);
  }

  const profileTexts = companies.map((company) =>
    companyProfileText(company, historyMap.get(company.company_id) ?? []),
  );
  const companyVectors = await createEmbeddings(profileTexts);

  await withTransaction(async (client) => {
    for (let i = 0; i < releaseRows.length; i += 1) {
      const row = releaseRows[i];
      await client.query(
        `
        INSERT INTO release_embedding
          (company_id, release_id, embedding, embedding_text, embedding_model, updated_at)
        VALUES ($1, $2, $3::vector, $4, $5, now())
        ON CONFLICT (company_id, release_id) DO UPDATE SET
          embedding = EXCLUDED.embedding,
          embedding_text = EXCLUDED.embedding_text,
          embedding_model = EXCLUDED.embedding_model,
          updated_at = now()
        `,
        [
          row.company_id,
          row.release_id,
          vectorLiteral(releaseVectors[i]),
          releaseTexts[i],
          config.openaiEmbeddingModel,
        ],
      );
    }

    for (let i = 0; i < companies.length; i += 1) {
      await client.query(
        `
        INSERT INTO company_pr_embedding
          (company_id, embedding, profile_text, embedding_model, updated_at)
        VALUES ($1, $2::vector, $3, $4, now())
        ON CONFLICT (company_id) DO UPDATE SET
          embedding = EXCLUDED.embedding,
          profile_text = EXCLUDED.profile_text,
          embedding_model = EXCLUDED.embedding_model,
          updated_at = now()
        `,
        [
          companies[i].company_id,
          vectorLiteral(companyVectors[i]),
          profileTexts[i],
          config.openaiEmbeddingModel,
        ],
      );
    }
  });

  return { releases: releaseRows.length, companies: companies.length };
}

export async function ensureEmbeddings(): Promise<void> {
  const counts = await pool.query(`
    SELECT
      (SELECT count(*) FROM release)::text AS release_count,
      (SELECT count(*) FROM release_embedding WHERE embedding_model = $1)::text AS embedding_count,
      (SELECT count(*) FROM company)::text AS company_count,
      (SELECT count(*) FROM company_pr_embedding WHERE embedding_model = $1)::text AS company_embedding_count
  `, [config.openaiEmbeddingModel]);

  const row = counts.rows[0];
  if (
    Number(row.release_count) !== Number(row.embedding_count) ||
    Number(row.company_count) !== Number(row.company_embedding_count)
  ) {
    console.log('Embedding cache is missing/stale. Refreshing with OpenAI Embeddings API...');
    await refreshAllEmbeddings();
  }
}
