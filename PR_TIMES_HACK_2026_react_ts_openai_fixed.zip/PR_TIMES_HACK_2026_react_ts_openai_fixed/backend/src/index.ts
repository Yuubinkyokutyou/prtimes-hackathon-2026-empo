import express, { NextFunction, Request, Response } from 'express';
import { config } from './config';
import { one, pool, query, waitForDatabase } from './db';
import { ensureEmbeddings, refreshAllEmbeddings } from './embeddings';
import {
  getCandidateList,
  getCompanyContext,
  getRecommendationBundle,
} from './recommendations';
import { getAnnualPlan } from './plans';

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));

function idParam(req: Request): number {
  const value = Number(req.params.companyId);
  if (!Number.isInteger(value) || value <= 0) {
    const error = new Error('invalid company id') as Error & { status?: number };
    error.status = 400;
    throw error;
  }
  return value;
}

app.get('/api/health', async (_req, res) => {
  const db = await one<{ now: string }>('SELECT now()::text AS now');
  const counts = await one<{
    releases: string;
    release_embeddings: string;
    company_embeddings: string;
  }>(`
    SELECT
      (SELECT count(*) FROM release)::text AS releases,
      (SELECT count(*) FROM release_embedding)::text AS release_embeddings,
      (SELECT count(*) FROM company_pr_embedding)::text AS company_embeddings
  `);
  res.json({
    ok: true,
    database: db?.now ?? null,
    openaiConfigured: Boolean(config.openaiApiKey),
    textModel: config.openaiTextModel,
    embeddingModel: config.openaiEmbeddingModel,
    counts,
  });
});

app.get('/api/companies', async (_req, res) => {
  const rows = await query(`
    SELECT c.company_id, c.company_name, c.description, c.industry_id, i.industry_name,
           max(r.created_at)::text AS last_release_at,
           count(r.release_id)::int AS release_count
    FROM company c
    JOIN industry i ON i.industry_id = c.industry_id
    LEFT JOIN release r ON r.company_id = c.company_id
    GROUP BY c.company_id, c.company_name, c.description, c.industry_id, i.industry_name
    ORDER BY c.company_id
  `);
  res.json(rows);
});

app.get('/api/companies/:companyId/dashboard', async (req, res) => {
  const companyId = idParam(req);
  const context = await getCompanyContext(companyId);
  const stats = await one<any>(`
    SELECT max(created_at)::text AS last_release_at,
           CASE WHEN max(created_at) IS NULL THEN NULL
                ELSE (CURRENT_DATE - max(created_at)::date)::int END AS days_since_last_release,
           count(*)::int AS release_count
    FROM release WHERE company_id = $1
  `, [companyId]);

  const allTypes = await query<{ release_type_id: number; release_type_name: string }>(`
    SELECT release_type_id, release_type_name FROM release_type ORDER BY release_type_id
  `);

  res.json({
    company: context.company,
    stats: {
      ...stats,
      isStopped: Number(stats?.days_since_last_release ?? 0) >= 90,
    },
    usedGenres: allTypes.filter((t) => context.usedTypes.has(Number(t.release_type_id))),
    unusedGenres: allTypes.filter((t) => !context.usedTypes.has(Number(t.release_type_id))),
    history: context.history,
  });
});

app.get('/api/companies/:companyId/recommendations', async (req, res) => {
  const companyId = idParam(req);
  const refresh = req.query.refresh === 'true';
  await ensureEmbeddings();
  const bundle = await getRecommendationBundle(companyId, refresh);
  res.json(bundle);
});

app.get('/api/companies/:companyId/recommendation-candidates', async (req, res) => {
  const companyId = idParam(req);
  await ensureEmbeddings();
  const candidates = await getCandidateList(companyId);
  res.json({ candidates });
});

app.get('/api/companies/:companyId/annual-plan', async (req, res) => {
  const companyId = idParam(req);
  const refresh = req.query.refresh === 'true';
  await ensureEmbeddings();
  const plan = await getAnnualPlan(companyId, refresh);
  res.json(plan);
});

app.post('/api/admin/embeddings/refresh', async (_req, res) => {
  const result = await refreshAllEmbeddings();
  await query('DELETE FROM ai_generation_cache');
  res.json({ ok: true, ...result });
});

app.post('/api/companies/:companyId/cache/clear', async (req, res) => {
  const companyId = idParam(req);
  await query('DELETE FROM ai_generation_cache WHERE company_id = $1', [companyId]);
  res.json({ ok: true });
});

app.use((req, res) => {
  res.status(404).json({ error: `Not found: ${req.method} ${req.path}` });
});

app.use(
  (error: Error & { status?: number }, _req: Request, res: Response, _next: NextFunction) => {
    console.error(error);
    const status = error.status ?? (error.message === 'company not found' ? 404 : 500);
    res.status(status).json({
      error: error.message,
      hint:
        error.message.includes('OPENAI_API_KEY')
          ? 'Set OPENAI_API_KEY in the root .env file and restart Docker Compose.'
          : undefined,
    });
  },
);

async function main(): Promise<void> {
  await waitForDatabase();
  app.listen(config.port, '0.0.0.0', () => {
    console.log(`PR recommendation API listening on :${config.port}`);
    console.log(`OpenAI text model: ${config.openaiTextModel}`);
    console.log(`OpenAI embedding model: ${config.openaiEmbeddingModel}`);
  });
}

main().catch(async (error) => {
  console.error('Fatal startup error:', error);
  await pool.end();
  process.exit(1);
});
