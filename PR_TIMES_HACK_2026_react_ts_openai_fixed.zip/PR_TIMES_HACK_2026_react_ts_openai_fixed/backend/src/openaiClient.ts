import OpenAI from 'openai';
import { config } from './config';

let singleton: OpenAI | null = null;

export function getOpenAI(): OpenAI {
  if (!config.openaiApiKey) {
    throw new Error(
      'OPENAI_API_KEY is not set. Copy .env.example to .env and set your API key.',
    );
  }
  if (!singleton) {
    singleton = new OpenAI({ apiKey: config.openaiApiKey });
  }
  return singleton;
}

export function cleanJsonText(text: string): string {
  const trimmed = text.trim();
  const fenced = trimmed.match(/^```(?:json)?\s*([\s\S]*?)\s*```$/i);
  if (fenced) return fenced[1].trim();
  const start = trimmed.indexOf('{');
  const end = trimmed.lastIndexOf('}');
  if (start >= 0 && end > start) return trimmed.slice(start, end + 1);
  return trimmed;
}
