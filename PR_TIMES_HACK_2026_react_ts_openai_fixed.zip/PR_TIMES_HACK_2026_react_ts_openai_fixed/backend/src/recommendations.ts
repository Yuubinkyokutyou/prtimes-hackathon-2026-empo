import { config } from './config';
import { one, query } from './db';
import { cleanJsonText, getOpenAI } from './openaiClient';
import {
  Candidate,
  Company,
  CrossoverRecommendation,
  GeneratedRecommendation,
  ReleaseHistory,
} from './types';

interface CachedRow {
  payload: unknown;
  model: string;
  generated_at: string;
}

export interface CompanyContext {
  company: Company;
  history: ReleaseHistory[];
  usedTypes: Set<number>;
}

export interface RecommendationBundle {
  generatedAt: string;
  model: string;
  aiStatus: 'ok' | 'fallback';
  standard: GeneratedRecommendation & { reference: Candidate };
  crossover: CrossoverRecommendation & {
    reference: Candidate;
    pastRelease: Candidate['closestPastRelease'];
  };
}

function num(value: unknown): number {
  return Number(value ?? 0);
}

export async function getCompanyContext(
  companyId: number,
): Promise<CompanyContext> {
  const company = await one<Company>(`
    SELECT c.company_id, c.company_name, c.description, c.industry_id, i.industry_name
    FROM company c
    JOIN industry i ON i.industry_id = c.industry_id
    WHERE c.company_id = $1
  `, [companyId]);
  if (!company) throw new Error('company not found');

  const history = await query<ReleaseHistory>(`
    SELECT r.company_id, r.release_id, r.title, r.subtitle, r.lead_paragraph, r.body,
           r.release_type_id, COALESCE(rt.release_type_name, '') AS release_type_name,
           r.created_at::text,
           COALESCE(rs.page_view, 0) AS page_view,
           COALESCE(rs.unique_user, 0) AS unique_user,
           COALESCE(rs.like_count, 0) AS like_count
    FROM release r
    LEFT JOIN release_type rt ON rt.release_type_id = r.release_type_id
    LEFT JOIN release_statistic rs ON rs.company_id = r.company_id AND rs.release_id = r.release_id
    WHERE r.company_id = $1
    ORDER BY r.created_at DESC
  `, [companyId]);

  return {
    company,
    history,
    usedTypes: new Set(
      history
        .map((r) => (r.release_type_id == null ? null : Number(r.release_type_id)))
        .filter((v): v is number => v !== null),
    ),
  };
}

export async function getCandidates(
  companyId: number,
  limit = 30,
): Promise<Candidate[]> {
  const context = await getCompanyContext(companyId);

  const rows = await query<any>(`
    SELECT
      r.company_id,
      r.release_id,
      c.company_name,
      c.industry_id AS company_industry_id,
      i.industry_name,
      r.title,
      r.lead_paragraph,
      r.release_type_id,
      COALESCE(rt.release_type_name, 'その他') AS release_type_name,
      r.created_at::text,
      COALESCE(rs.page_view, 0) AS page_view,
      GREATEST(0, LEAST(1, 1 - (re.embedding <=> cpe.embedding))) AS similarity,
      past.release_id AS past_release_id,
      past.title AS past_title,
      past.release_type_name AS past_release_type_name,
      past.similarity AS past_similarity
    FROM release_embedding re
    JOIN company_pr_embedding cpe ON cpe.company_id = $1
    JOIN release r ON r.company_id = re.company_id AND r.release_id = re.release_id
    JOIN company c ON c.company_id = r.company_id
    JOIN industry i ON i.industry_id = c.industry_id
    LEFT JOIN release_type rt ON rt.release_type_id = r.release_type_id
    LEFT JOIN release_statistic rs ON rs.company_id = r.company_id AND rs.release_id = r.release_id
    LEFT JOIN LATERAL (
      SELECT tr.release_id,
             tr.title,
             COALESCE(trt.release_type_name, 'その他') AS release_type_name,
             GREATEST(0, LEAST(1, 1 - (tre.embedding <=> re.embedding))) AS similarity
      FROM release_embedding tre
      JOIN release tr ON tr.company_id = tre.company_id AND tr.release_id = tre.release_id
      LEFT JOIN release_type trt ON trt.release_type_id = tr.release_type_id
      WHERE tre.company_id = $1
      ORDER BY tre.embedding <=> re.embedding
      LIMIT 1
    ) past ON true
    WHERE r.company_id <> $1
    ORDER BY re.embedding <=> cpe.embedding
    LIMIT $2
  `, [companyId, limit]);

  const maxPv = Math.max(1, ...rows.map((r) => num(r.page_view)));
  const candidates = rows.map((row): Candidate => {
    const similarity = num(row.similarity);
    const pageView = num(row.page_view);
    const popularity = Math.log1p(pageView) / Math.log1p(maxPv);
    const releaseTypeId =
      row.release_type_id == null ? null : Number(row.release_type_id);
    const isNewGenre =
      releaseTypeId !== null && !context.usedTypes.has(releaseTypeId);
    const sameIndustry =
      Number(row.company_industry_id) === Number(context.company.industry_id);
    const score =
      similarity * 0.55 +
      (isNewGenre ? 0.2 : 0) +
      (sameIndustry ? 0.1 : 0) +
      popularity * 0.15;

    return {
      company_id: Number(row.company_id),
      release_id: Number(row.release_id),
      company_name: row.company_name,
      company_industry_id: Number(row.company_industry_id),
      industry_name: row.industry_name,
      title: row.title,
      lead_paragraph: row.lead_paragraph,
      release_type_id: releaseTypeId,
      release_type_name: row.release_type_name,
      created_at: row.created_at,
      page_view: pageView,
      similarity,
      sameIndustry,
      isNewGenre,
      popularity,
      score,
      closestPastRelease: row.past_release_id
        ? {
            release_id: Number(row.past_release_id),
            title: row.past_title,
            release_type_name: row.past_release_type_name,
            similarity: num(row.past_similarity),
          }
        : undefined,
    };
  });

  return candidates.sort((a, b) => b.score - a.score);
}

function pickFeatured(candidates: Candidate[]): {
  standard: Candidate;
  crossover: Candidate;
} {
  if (candidates.length === 0) throw new Error('no recommendation candidates');
  const newGenres = candidates.filter((c) => c.isNewGenre);
  const standard = newGenres[0] ?? candidates[0];

  const crossoverPool = (newGenres.length ? newGenres : candidates)
    .filter(
      (c) =>
        !(c.company_id === standard.company_id && c.release_id === standard.release_id),
    )
    .map((c) => ({
      candidate: c,
      crossoverScore:
        c.score * 0.7 + (c.closestPastRelease?.similarity ?? 0) * 0.3,
    }))
    .sort((a, b) => b.crossoverScore - a.crossoverScore);

  return {
    standard,
    crossover: crossoverPool[0]?.candidate ?? standard,
  };
}

async function readCache(
  companyId: number,
  key: string,
): Promise<CachedRow | null> {
  return one<CachedRow>(`
    SELECT payload, model, generated_at::text
    FROM ai_generation_cache
    WHERE company_id = $1 AND cache_key = $2
  `, [companyId, key]);
}

async function saveCache(
  companyId: number,
  key: string,
  payload: unknown,
): Promise<void> {
  await query(`
    INSERT INTO ai_generation_cache(company_id, cache_key, payload, model, generated_at)
    VALUES ($1, $2, $3::jsonb, $4, now())
    ON CONFLICT (company_id, cache_key) DO UPDATE SET
      payload = EXCLUDED.payload,
      model = EXCLUDED.model,
      generated_at = now()
  `, [companyId, key, JSON.stringify(payload), config.openaiTextModel]);
}

function fallbackRecommendation(
  context: CompanyContext,
  standard: Candidate,
  crossover: Candidate,
): RecommendationBundle {
  const past = crossover.closestPastRelease ?? {
    release_id: context.history[0]?.release_id ?? 0,
    title: context.history[0]?.title ?? '過去の配信',
    release_type_name: context.history[0]?.release_type_name ?? '',
    similarity: 0,
  };
  return {
    generatedAt: new Date().toISOString(),
    model: config.openaiTextModel,
    aiStatus: 'fallback',
    standard: {
      headline: `${standard.release_type_name}を次の発信テーマに`,
      genre: standard.release_type_name,
      proposal: `${standard.company_name}の「${standard.title}」を参考に、自社で同ジャンルの事実を探して発信します。`,
      why: '自社ではまだ扱っていないジャンルで、企業プロフィールとの類似度が高い事例だからです。',
      next_actions: ['社内に該当する事実があるか確認する', '数字・時期・担当者コメントを集める', 'タイトル案を作る'],
      reference: standard,
    },
    crossover: {
      headline: `「${past.title}」の続編を${crossover.release_type_name}として発信`,
      genre: crossover.release_type_name,
      proposal: `過去の「${past.title}」で扱ったテーマを土台に、${crossover.release_type_name}の切り口へ展開します。`,
      past_release_hook: `過去配信「${past.title}」を再利用し、その後の変化・利用データ・顧客の声を新ジャンルに変換します。`,
      why: 'ゼロから新しいネタを探すのではなく、既に発信した事実の「その後」を使えるため、社内情報を集めやすいからです。',
      next_actions: ['過去配信後に変わった数字を確認する', '顧客・現場の声を1件集める', '新ジャンルとして成立する根拠を整理する'],
      reference: crossover,
      pastRelease: past,
    },
  };
}

function validateGenerated(value: any): boolean {
  const validRec = (rec: any) =>
    rec &&
    typeof rec.headline === 'string' &&
    typeof rec.genre === 'string' &&
    typeof rec.proposal === 'string' &&
    typeof rec.why === 'string' &&
    Array.isArray(rec.next_actions);
  return validRec(value?.standard) && validRec(value?.crossover) &&
    typeof value.crossover.past_release_hook === 'string';
}

export async function getRecommendationBundle(
  companyId: number,
  refresh = false,
): Promise<RecommendationBundle> {
  const cacheKey = `${config.cacheVersion}:recommendations`;
  if (!refresh) {
    const cached = await readCache(companyId, cacheKey);
    if (cached?.payload) return cached.payload as RecommendationBundle;
  }

  const context = await getCompanyContext(companyId);
  const candidates = await getCandidates(companyId, 40);
  const { standard, crossover } = pickFeatured(candidates);
  const past = crossover.closestPastRelease ?? {
    release_id: context.history[0]?.release_id ?? 0,
    title: context.history[0]?.title ?? '過去の配信',
    release_type_name: context.history[0]?.release_type_name ?? '',
    similarity: 0,
  };

  const historySummary = context.history.slice(0, 8).map((r) => ({
    date: r.created_at,
    genre: r.release_type_name,
    title: r.title,
    lead: r.lead_paragraph,
  }));

  const prompt = `
あなたは中小企業の継続的なプレスリリース配信を支援するPRコンサルタントです。
以下の事実だけを使って、次のプレスリリース提案を2種類作ってください。

【対象企業】
${JSON.stringify(context.company, null, 2)}

【過去配信】
${JSON.stringify(historySummary, null, 2)}

【通常提案に使う他社事例】
${JSON.stringify(standard, null, 2)}

【掛け合わせ提案に使う他社事例】
${JSON.stringify(crossover, null, 2)}

【掛け合わせる対象企業の過去配信】
${JSON.stringify(past, null, 2)}

要件:
- standard: 自社がまだ配信していない新ジャンルを中心に「次の1本」を提案する。
- crossover: 対象企業の過去配信の内容と、新ジャンルを掛け合わせた「続編・発展形」を提案する。
- 他社事例をそのまま真似するのではなく、対象企業の事業に合わせる。
- 入力にない売上、導入社数、顧客数などの数字を捏造しない。不明な数字は「確認する」「集める」と表現する。
- 「ニュース性が弱いから出せない」ではなく、小さな変化でも継続発信できる切り口にする。
- 日本語で、担当者がそのまま社内に共有できる具体性にする。
- next_actions は3項目、各40文字以内。
- 出力は説明文やMarkdownを付けず、次のJSON形式だけにする。

{
  "standard": {
    "headline": "30〜55文字程度の提案タイトル",
    "genre": "ジャンル名",
    "proposal": "100〜180文字程度の具体案",
    "why": "なぜこの企業に合うかを80〜140文字程度",
    "next_actions": ["...", "...", "..."]
  },
  "crossover": {
    "headline": "30〜55文字程度の提案タイトル",
    "genre": "ジャンル名",
    "proposal": "100〜180文字程度の具体案",
    "past_release_hook": "過去配信のどこを再利用し、どう新ジャンルに変えるかを80〜140文字程度",
    "why": "なぜ継続配信につながるかを80〜140文字程度",
    "next_actions": ["...", "...", "..."]
  }
}
`.trim();

  let bundle: RecommendationBundle;
  try {
    const client = getOpenAI();
    const response = await client.responses.create({
      model: config.openaiTextModel,
      instructions:
        '事実に忠実な日本語のPR企画を作成してください。指定JSON以外は出力しないでください。',
      input: prompt,
    });
    const parsed = JSON.parse(cleanJsonText(response.output_text));
    if (!validateGenerated(parsed)) throw new Error('invalid JSON shape from OpenAI');

    bundle = {
      generatedAt: new Date().toISOString(),
      model: config.openaiTextModel,
      aiStatus: 'ok',
      standard: { ...parsed.standard, reference: standard },
      crossover: {
        ...parsed.crossover,
        reference: crossover,
        pastRelease: past,
      },
    };
  } catch (error) {
    console.error('OpenAI recommendation generation failed:', error);
    bundle = fallbackRecommendation(context, standard, crossover);
  }

  await saveCache(companyId, cacheKey, bundle);
  return bundle;
}

export async function getCandidateList(companyId: number): Promise<Candidate[]> {
  return (await getCandidates(companyId, 60)).slice(0, 20);
}
