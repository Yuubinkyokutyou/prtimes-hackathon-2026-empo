#!/usr/bin/env sh
set -eu

ROOT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)
ENV_FILE="$ROOT_DIR/.env"

if [ -f "$ENV_FILE" ]; then
  printf '.env already exists: %s\n' "$ENV_FILE"
  printf 'Remove it first if you want to recreate it.\n'
  exit 1
fi

printf 'Enter a NEW OpenAI API key (input is hidden): '
stty -echo
IFS= read -r OPENAI_KEY
stty echo
printf '\n'

if [ -z "$OPENAI_KEY" ]; then
  echo 'OPENAI API key is required.' >&2
  exit 1
fi

cat > "$ENV_FILE" <<ENVEOF
OPENAI_API_KEY=$OPENAI_KEY
OPENAI_TEXT_MODEL=gpt-5.6-terra
OPENAI_EMBEDDING_MODEL=text-embedding-3-small

POSTGRES_DB=prtimes
POSTGRES_USER=prtimes
POSTGRES_PASSWORD=prtimes-local
POSTGRES_PORT=5432
APP_PORT=80
ENVEOF

chmod 600 "$ENV_FILE" 2>/dev/null || true
printf 'Created %s\n' "$ENV_FILE"
printf 'Run: docker compose up --build\n'
