#!/usr/bin/env sh
set -eu
BASE_URL="${BASE_URL:-http://localhost:${APP_PORT:-80}}"

echo "[1/5] health"
curl -fsS "$BASE_URL/api/health" >/dev/null

echo "[2/5] companies"
curl -fsS "$BASE_URL/api/companies" >/dev/null

echo "[3/5] dashboard"
curl -fsS "$BASE_URL/api/companies/1/dashboard" >/dev/null

echo "[4/5] OpenAI recommendations + embeddings"
curl -fsS "$BASE_URL/api/companies/1/recommendations" >/dev/null

echo "[5/5] annual plan"
curl -fsS "$BASE_URL/api/companies/1/annual-plan" >/dev/null

echo "SMOKE TEST OK"
