-- Vector / recommendation tables added on top of the original PR TIMES schema.

CREATE TABLE IF NOT EXISTS release_embedding (
    company_id integer NOT NULL,
    release_id integer NOT NULL,
    embedding vector(384) NOT NULL,
    embedding_text text NOT NULL DEFAULT '',
    embedding_model varchar(100) NOT NULL DEFAULT 'text-embedding-3-small',
    updated_at timestamp without time zone NOT NULL DEFAULT now(),
    CONSTRAINT release_embedding_pkey PRIMARY KEY (company_id, release_id),
    CONSTRAINT release_embedding_release_fkey FOREIGN KEY (company_id, release_id)
        REFERENCES release (company_id, release_id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS release_embedding_hnsw_idx
    ON release_embedding USING hnsw (embedding vector_cosine_ops);

CREATE TABLE IF NOT EXISTS company_pr_embedding (
    company_id integer PRIMARY KEY REFERENCES company(company_id) ON DELETE CASCADE,
    embedding vector(384) NOT NULL,
    profile_text text NOT NULL DEFAULT '',
    embedding_model varchar(100) NOT NULL DEFAULT 'text-embedding-3-small',
    updated_at timestamp without time zone NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS ai_generation_cache (
    id bigserial PRIMARY KEY,
    company_id integer NOT NULL REFERENCES company(company_id) ON DELETE CASCADE,
    cache_key varchar(100) NOT NULL,
    payload jsonb NOT NULL,
    model varchar(100) NOT NULL DEFAULT '',
    generated_at timestamp without time zone NOT NULL DEFAULT now(),
    UNIQUE(company_id, cache_key)
);

CREATE INDEX IF NOT EXISTS release_company_created_idx
    ON release (company_id, created_at DESC);
CREATE INDEX IF NOT EXISTS release_type_idx
    ON release (release_type_id);
