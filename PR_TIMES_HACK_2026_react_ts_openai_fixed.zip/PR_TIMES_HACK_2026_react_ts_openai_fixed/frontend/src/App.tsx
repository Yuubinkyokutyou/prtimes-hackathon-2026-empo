import { useEffect, useMemo, useState } from 'react';
import { api } from './api';
import type {
  AnnualPlan,
  Candidate,
  CompanyListItem,
  Dashboard,
  Recommendation,
  RecommendationBundle,
} from './types';

function formatDate(value: string | null | undefined): string {
  if (!value) return '—';
  const date = new Date(value);
  return new Intl.DateTimeFormat('ja-JP', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  }).format(date);
}

function percent(value: number): string {
  return `${Math.round(value * 100)}%`;
}

function RecommendationCard({
  eyebrow,
  recommendation,
  crossover = false,
}: {
  eyebrow: string;
  recommendation: Recommendation & { past_release_hook?: string; pastRelease?: Candidate['closestPastRelease'] };
  crossover?: boolean;
}) {
  return (
    <article className={`recommendation-card ${crossover ? 'crossover' : ''}`}>
      <div className="card-topline">
        <span className="eyebrow">{eyebrow}</span>
        <span className="genre-pill">{recommendation.genre}</span>
      </div>
      <h3>{recommendation.headline}</h3>
      <p className="proposal-text">{recommendation.proposal}</p>

      {crossover && recommendation.past_release_hook && (
        <div className="hook-box">
          <span>過去配信との掛け合わせ</span>
          <strong>{recommendation.pastRelease?.title ?? '過去配信'}</strong>
          <p>{recommendation.past_release_hook}</p>
        </div>
      )}

      <div className="reason-box">
        <span>この提案の理由</span>
        <p>{recommendation.why}</p>
      </div>

      <div className="actions-block">
        <span>まず集める情報</span>
        <ol>
          {recommendation.next_actions.map((action) => (
            <li key={action}>{action}</li>
          ))}
        </ol>
      </div>

      <div className="reference-box">
        <div>
          <span className="reference-label">参考にした他社事例</span>
          <strong>{recommendation.reference.company_name}</strong>
          <p>{recommendation.reference.title}</p>
        </div>
        <div className="reference-score">
          <span>類似度</span>
          <strong>{percent(recommendation.reference.similarity)}</strong>
        </div>
      </div>
    </article>
  );
}

function CandidateDrawer({
  open,
  candidates,
  loading,
  onClose,
}: {
  open: boolean;
  candidates: Candidate[];
  loading: boolean;
  onClose: () => void;
}) {
  if (!open) return null;
  return (
    <div className="drawer-layer" onMouseDown={onClose}>
      <aside className="drawer" onMouseDown={(e) => e.stopPropagation()}>
        <div className="drawer-header">
          <div>
            <span className="eyebrow">VECTOR SEARCH</span>
            <h2>類似する他社事例一覧</h2>
          </div>
          <button className="icon-button" onClick={onClose} aria-label="閉じる">
            ×
          </button>
        </div>
        <p className="drawer-intro">
          メイン画面では1件に絞り、必要なときだけ候補全体を確認できます。未配信ジャンル・同業界・反応実績も含めて並べています。
        </p>
        {loading ? (
          <div className="loading-panel">類似事例を検索しています…</div>
        ) : (
          <div className="candidate-list">
            {candidates.map((candidate, index) => (
              <article className="candidate-row" key={`${candidate.company_id}-${candidate.release_id}`}>
                <div className="candidate-rank">{String(index + 1).padStart(2, '0')}</div>
                <div className="candidate-main">
                  <div className="candidate-meta">
                    <span>{candidate.release_type_name}</span>
                    {candidate.isNewGenre && <span className="new-badge">未配信ジャンル</span>}
                    {candidate.sameIndustry && <span className="same-badge">同業界</span>}
                  </div>
                  <h3>{candidate.title}</h3>
                  <p>{candidate.company_name} ・ {candidate.industry_name}</p>
                  {candidate.closestPastRelease && (
                    <div className="candidate-hook">
                      自社の「{candidate.closestPastRelease.title}」と相性 {percent(candidate.closestPastRelease.similarity)}
                    </div>
                  )}
                </div>
                <div className="candidate-numbers">
                  <span>類似度 <strong>{percent(candidate.similarity)}</strong></span>
                  <span>PV <strong>{candidate.page_view.toLocaleString()}</strong></span>
                </div>
              </article>
            ))}
          </div>
        )}
      </aside>
    </div>
  );
}

export default function App() {
  const [companies, setCompanies] = useState<CompanyListItem[]>([]);
  const [companyId, setCompanyId] = useState(1);
  const [dashboard, setDashboard] = useState<Dashboard | null>(null);
  const [recommendations, setRecommendations] = useState<RecommendationBundle | null>(null);
  const [plan, setPlan] = useState<AnnualPlan | null>(null);
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [tab, setTab] = useState<'recommendations' | 'plan'>('recommendations');
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [loadingCandidates, setLoadingCandidates] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    api.companies()
      .then((items) => {
        setCompanies(items);
        if (items.length && !items.some((item) => item.company_id === companyId)) {
          setCompanyId(items[0].company_id);
        }
      })
      .catch((e) => setError(e.message));
  }, []);

  async function loadCompany(id: number) {
    setLoading(true);
    setError(null);
    try {
      const dashboardData = await api.dashboard(id);
      setDashboard(dashboardData);
      setPlan(null);
      setCandidates([]);
      try {
        setRecommendations(await api.recommendations(id));
      } catch (aiError) {
        setRecommendations(null);
        setError(aiError instanceof Error ? aiError.message : String(aiError));
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void loadCompany(companyId);
  }, [companyId]);

  async function openCandidates() {
    setDrawerOpen(true);
    if (candidates.length) return;
    setLoadingCandidates(true);
    try {
      const data = await api.candidates(companyId);
      setCandidates(data.candidates);
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoadingCandidates(false);
    }
  }

  async function showPlan() {
    setTab('plan');
    if (plan) return;
    setLoading(true);
    setError(null);
    try {
      setPlan(await api.plan(companyId));
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setLoading(false);
    }
  }

  async function refreshAi() {
    setRefreshing(true);
    setError(null);
    try {
      if (tab === 'recommendations') {
        setRecommendations(await api.recommendations(companyId, true));
        setCandidates([]);
      } else {
        setPlan(await api.plan(companyId, true));
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : String(e));
    } finally {
      setRefreshing(false);
    }
  }

  const unusedText = useMemo(
    () => dashboard?.unusedGenres.slice(0, 5).map((g) => g.release_type_name).join('・') ?? '',
    [dashboard],
  );

  return (
    <div className="app-shell">
      <header className="topbar">
        <div className="brand">
          <div className="brand-mark">PR</div>
          <div>
            <strong>Continuity Assistant</strong>
            <span>配信を「1回」で終わらせない</span>
          </div>
        </div>
        <div className="top-actions">
          <select
            value={companyId}
            onChange={(e) => setCompanyId(Number(e.target.value))}
            aria-label="企業を選択"
          >
            {companies.map((company) => (
              <option key={company.company_id} value={company.company_id}>
                {company.company_name}
              </option>
            ))}
          </select>
          <button className="ghost-button" onClick={refreshAi} disabled={refreshing || loading}>
            {refreshing ? 'OpenAI生成中…' : 'AI提案を再生成'}
          </button>
        </div>
      </header>

      <main>
        {error && (
          <div className="error-banner">
            <strong>エラー</strong>
            <pre>{error}</pre>
          </div>
        )}

        {loading && !dashboard ? (
          <section className="hero loading-hero">
            <div className="spinner" />
            <div>
              <h1>企業の過去配信と他社事例を分析しています</h1>
              <p>初回はOpenAI Embeddings APIでベクトルを作るため少し時間がかかります。</p>
            </div>
          </section>
        ) : dashboard ? (
          <>
            <section className="hero">
              <div className="hero-copy">
                <span className="eyebrow">PR CONTINUITY</span>
                <h1>{dashboard.company.company_name}の<br />次の発信を、止めない。</h1>
                <p>
                  過去の配信履歴と、意味的に近い他社の投稿済みプレスリリースを掛け合わせて、
                  「次の1本」と「過去配信の発展形」を提案します。
                </p>
                <div className="hero-tags">
                  <span>{dashboard.company.industry_name}</span>
                  <span>{dashboard.stats.release_count}本の配信履歴</span>
                  <span>OpenAI × pgvector</span>
                </div>
              </div>
              <div className={`status-card ${dashboard.stats.isStopped ? 'stopped' : ''}`}>
                <span className="status-label">配信ステータス</span>
                <strong>{dashboard.stats.isStopped ? '配信が止まっています' : '継続配信中'}</strong>
                <div className="status-number">
                  <b>{dashboard.stats.days_since_last_release ?? 0}</b><span>日</span>
                </div>
                <p>最終配信から経過</p>
                <div className="status-foot">
                  最終配信 {formatDate(dashboard.stats.last_release_at)}
                </div>
              </div>
            </section>

            <section className="insight-strip">
              <div>
                <span>これまで使ったジャンル</span>
                <strong>{dashboard.usedGenres.map((g) => g.release_type_name).join('・') || 'なし'}</strong>
              </div>
              <div>
                <span>まだ使っていないジャンル</span>
                <strong>{unusedText || 'ほぼ網羅済み'}</strong>
              </div>
            </section>

            <div className="tabbar">
              <button
                className={tab === 'recommendations' ? 'active' : ''}
                onClick={() => setTab('recommendations')}
              >
                今出すなら
              </button>
              <button
                className={tab === 'plan' ? 'active' : ''}
                onClick={showPlan}
              >
                12か月PR計画
              </button>
            </div>

            {tab === 'recommendations' && recommendations && (
              <section className="recommendation-section">
                <div className="section-heading">
                  <div>
                    <span className="eyebrow">FEATURED RECOMMENDATIONS</span>
                    <h2>おすすめは、あえて2つだけ。</h2>
                    <p>選択肢を増やしすぎず、いま動ける提案を1件ずつ提示します。</p>
                  </div>
                  <button className="link-button" onClick={openCandidates}>
                    他の候補・事例一覧を見る →
                  </button>
                </div>

                {recommendations.aiStatus === 'fallback' && (
                  <div className="ai-warning">
                    OpenAI文章生成に失敗したためフォールバック文を表示しています。.envのキー・モデル名・API利用状況を確認してください。
                  </div>
                )}

                <div className="recommendation-grid">
                  <RecommendationCard
                    eyebrow="01 / 次の1本"
                    recommendation={recommendations.standard}
                  />
                  <RecommendationCard
                    eyebrow="02 / 過去配信 × 新ジャンル"
                    recommendation={recommendations.crossover}
                    crossover
                  />
                </div>

                <div className="history-section">
                  <div className="section-heading compact">
                    <div>
                      <span className="eyebrow">YOUR HISTORY</span>
                      <h2>これまでの配信</h2>
                    </div>
                  </div>
                  <div className="history-list">
                    {dashboard.history.map((release) => (
                      <article key={release.release_id}>
                        <time>{formatDate(release.created_at)}</time>
                        <div>
                          <span>{release.release_type_name}</span>
                          <h3>{release.title}</h3>
                        </div>
                        <strong>{release.page_view.toLocaleString()} PV</strong>
                      </article>
                    ))}
                  </div>
                </div>
              </section>
            )}

            {tab === 'plan' && (
              <section className="plan-section">
                <div className="section-heading">
                  <div>
                    <span className="eyebrow">12 MONTHS PR PLAN</span>
                    <h2>次の1本だけでなく、止まらない年間計画へ。</h2>
                    <p>OpenAIが過去配信・未配信ジャンル・類似事例を混ぜて、月1件に絞ります。</p>
                  </div>
                </div>
                {loading && !plan ? (
                  <div className="loading-panel">年間PR計画を生成しています…</div>
                ) : plan ? (
                  <div className="plan-grid">
                    {plan.months.map((item, index) => (
                      <article className="plan-card" key={`${item.month}-${index}`}>
                        <div className="plan-month">{item.month}</div>
                        <span className="genre-pill">{item.genre}</span>
                        <h3>{item.headline}</h3>
                        <p>{item.concept}</p>
                        <div className="plan-source">起点：{item.source}</div>
                        <div className="plan-info">
                          <span>社内で確認</span>
                          <ul>
                            {item.internalInfo.map((info) => <li key={info}>{info}</li>)}
                          </ul>
                        </div>
                      </article>
                    ))}
                  </div>
                ) : null}
              </section>
            )}
          </>
        ) : null}
      </main>

      <CandidateDrawer
        open={drawerOpen}
        candidates={candidates}
        loading={loadingCandidates}
        onClose={() => setDrawerOpen(false)}
      />
    </div>
  );
}
