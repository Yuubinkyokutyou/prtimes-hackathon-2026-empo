export interface CompanyListItem {
  company_id: number;
  company_name: string;
  description: string;
  industry_id: number;
  industry_name: string;
  last_release_at: string | null;
  release_count: number;
}

export interface Release {
  company_id: number;
  release_id: number;
  title: string;
  lead_paragraph: string;
  body: string;
  release_type_id: number | null;
  release_type_name: string;
  created_at: string;
  page_view: number;
  unique_user: number;
  like_count: number;
}

export interface Dashboard {
  company: CompanyListItem;
  stats: {
    last_release_at: string | null;
    days_since_last_release: number | null;
    release_count: number;
    isStopped: boolean;
  };
  usedGenres: { release_type_id: number; release_type_name: string }[];
  unusedGenres: { release_type_id: number; release_type_name: string }[];
  history: Release[];
}

export interface Candidate {
  company_id: number;
  release_id: number;
  company_name: string;
  industry_name: string;
  title: string;
  lead_paragraph: string;
  release_type_name: string;
  created_at: string;
  page_view: number;
  similarity: number;
  isNewGenre: boolean;
  sameIndustry: boolean;
  score: number;
  closestPastRelease?: {
    release_id: number;
    title: string;
    release_type_name: string;
    similarity: number;
  };
}

export interface Recommendation {
  headline: string;
  genre: string;
  proposal: string;
  why: string;
  next_actions: string[];
  reference: Candidate;
}

export interface RecommendationBundle {
  generatedAt: string;
  model: string;
  aiStatus: 'ok' | 'fallback';
  standard: Recommendation;
  crossover: Recommendation & {
    past_release_hook: string;
    pastRelease?: Candidate['closestPastRelease'];
  };
}

export interface AnnualPlan {
  generatedAt: string;
  model: string;
  aiStatus: 'ok' | 'fallback';
  months: {
    month: string;
    genre: string;
    headline: string;
    concept: string;
    source: string;
    internalInfo: string[];
  }[];
}
