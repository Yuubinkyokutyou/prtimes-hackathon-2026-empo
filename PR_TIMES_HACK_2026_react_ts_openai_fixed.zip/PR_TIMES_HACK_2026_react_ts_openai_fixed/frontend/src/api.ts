async function request<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, options);
  if (!response.ok) {
    let message = `${response.status} ${response.statusText}`;
    try {
      const body = await response.json();
      message = body.error ?? message;
      if (body.hint) message += `\n${body.hint}`;
    } catch {
      // ignore body parse errors
    }
    throw new Error(message);
  }
  return response.json() as Promise<T>;
}

export const api = {
  companies: () => request<import('./types').CompanyListItem[]>('/api/companies'),
  dashboard: (companyId: number) =>
    request<import('./types').Dashboard>(`/api/companies/${companyId}/dashboard`),
  recommendations: (companyId: number, refresh = false) =>
    request<import('./types').RecommendationBundle>(
      `/api/companies/${companyId}/recommendations${refresh ? '?refresh=true' : ''}`,
    ),
  candidates: (companyId: number) =>
    request<{ candidates: import('./types').Candidate[] }>(
      `/api/companies/${companyId}/recommendation-candidates`,
    ),
  plan: (companyId: number, refresh = false) =>
    request<import('./types').AnnualPlan>(
      `/api/companies/${companyId}/annual-plan${refresh ? '?refresh=true' : ''}`,
    ),
};
